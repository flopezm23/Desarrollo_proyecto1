package com.proyecto1.security;

public class WebSecurityConfigurerAdapter {
}
