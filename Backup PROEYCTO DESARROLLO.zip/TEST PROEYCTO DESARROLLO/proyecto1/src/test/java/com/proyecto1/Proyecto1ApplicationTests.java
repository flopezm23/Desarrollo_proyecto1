package com.proyecto1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto1ApplicationTests {

	@Test
	void contextLoads() {
		// Prueba si el contexto de la aplicación carga correctamente
	}
}
